


let start = document.getElementById("start_button");

start.onclick = function () {
    window.location.href = "/research";
}